/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Latop RogStrix
 */
public class Respuesta {
    
private int idRespuesta;
    private String texto;
    private String fechayHora;
    private Comentario comentario;
    private Usuario usuario;

    public Respuesta(int idRespuesta, String texto, String fechayHora, Comentario comentario, Usuario usuario){
        this.idRespuesta=idRespuesta;
        this.texto=texto;
        this.fechayHora=fechayHora;
        this.comentario=comentario;
        this.usuario=usuario;
    }

    public Respuesta(){
    }

    public int getIdRespuesta(){
        return idRespuesta;
    }

    public void setIdRespuesta(int idRespuesta){
        this.idRespuesta=idRespuesta;
    }

    public String getTexto(){
        return texto;
    }

    public void setTexto(String texto){
        this.texto=texto;
    }

    public String getFechayHora(){
        return fechayHora;
    }

    public void setFechayHora(String fechayHora){
        this.fechayHora=fechayHora;
    }

    public Comentario getComentario(){
        return comentario;
    }

    public void setComentario(Comentario comentario){
        this.comentario=comentario;
    }

    public Usuario getUsuario(){
        return usuario;
    }

    public void setUsuario(Usuario usuario){
        this.usuario=usuario;
    }
}