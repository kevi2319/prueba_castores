
package bd;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Latop RogStrix
 */
public class ConexionMySQL {
    Connection conn;
    public Connection open(){
        String usuario="root";
       
        String contrasenia="admin"; 
        
                                               /*Aqui va Nom.BD?useSSL=false&"  */
        String url="jdbc:mysql://127.0.0.1:3306/gomez_kevin?useSSL=false&"
                  +"allowPublicKeyRetrieval=true&"
                  +"useUnicode=true&characterEncoding=utf-8";
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn=DriverManager.getConnection(url, usuario, contrasenia);
            return conn;
        } catch(Exception e){
            throw new RuntimeException(e);
        }
    }
    
    public void close(){
        if(conn!=null){
            try{
                conn.close();
            } catch(Exception e){
                e.printStackTrace();
                System.out.println("Exception controlada.");
            }
        }
    }
}
    
