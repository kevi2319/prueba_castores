/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rest;
import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import core.ControllerComent;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import model.Comentario;

/**
 *
 * @author Latop RogStrix
 */
@Path("comentario")
public class RESTComentario {
    
@Path("agregar")
    @Produces(MediaType.APPLICATION_JSON)
    @POST
    public Response agregar(@FormParam("datos") @DefaultValue("") String datos){
        String out="";
        Gson gson=new Gson();
        Comentario c=new Comentario();
        ControllerComent cc=new ControllerComent();
        
        try{
            c=gson.fromJson(datos, Comentario.class);
            cc.guardarComentario(c);
            out=gson.toJson(c);
        } catch(JsonParseException jpe){
            jpe.printStackTrace();
            out= """
                {"exception":"Formato JSON de Datos Incorrectos"}
                """;
        } catch(Exception e){
            e.printStackTrace();
            out="""
                {"exception":"%s"}
                """;
            out=String.format(out, e.toString());
        }
        
        return Response.status(Response.Status.OK).entity(out).build();
    }
    
    @Path("getAll")
    @Produces(MediaType.APPLICATION_JSON)
    @GET
    public Response getAll(){
        String out="";
        Gson gson=new Gson();
        List<Comentario> comentarios=new ArrayList<>();
        ControllerComent cc=new ControllerComent();
        
        try{
            comentarios=cc.getAll();
            out=gson.toJson(comentarios);
        } catch(Exception e){
            e.printStackTrace();
            out="{\"exception\":\"Error interno del servidor.\"}";
        }
        
        return Response.status(Response.Status.OK).entity(out).build();
    }
}