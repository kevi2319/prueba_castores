-- Autor:   Kevin Agustin Gomez Martinez	---------------							
-- Email:    kevin.martinez1906@gmail.com --------        - 
-- Fecha de elaboracion: 06-07-2023   ---------           -
--                  Prueba Castores                                        -
-- --------------------------------------------------------
DROP DATABASE IF EXISTS gomez_kevin;

CREATE DATABASE gomez_kevin;

USE gomez_kevin;

CREATE TABLE personal(
	idPersonal			INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    apellidoPaterno 	VARCHAR(45) NOT NULL,
    apellidoMaterno		VARCHAR(45) NOT NULL,
    nombre				VARCHAR(45) NOT NULL,
    direccion			VARCHAR(45) NOT NULL,
    fechaIngreso		DATE NOT NULL
);

INSERT INTO personal(apellidoPaterno, apellidoMaterno, nombre, direccion, fechaIngreso) VALUES("Gomez", "Martinez", "Kevin Agustin", "Santa Fabiola 130", STR_TO_DATE("05/07/2023", '%d/%m/%Y'));
-- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------





CREATE TABLE usuario(
	idUsuario			INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nombreUsuario		VARCHAR(20) NOT NULL,
    contrasenia			VARCHAR(40) NOT NULL,
    correo				VARCHAR(45) NOT NULL,
    esInterno			VARCHAR(45) NOT NULL
);
INSERT INTO usuario(nombreUsuario, contrasenia, correo, esInterno) VALUES("Kev", "2312", "kevin.martinez1906@gmail.com", "Interno");

INSERT INTO usuario(nombreUsuario, contrasenia, correo, esInterno) VALUES("Ale", "2311", "alesada31gmail.com", "Externo");

SELECT * FROM usuario WHERE nombreUsuario="Kev" AND contrasenia="2312";
-- -------------------------------------------------------------------------------------------------------------------------------------------------------





CREATE TABLE noticia(
	idNoticia			INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    titulo				VARCHAR(45),
    contenido			VARCHAR(1000),
    fechaPublicacion	DATETIME,
    idPersonal			INT NOT NULL,
    CONSTRAINT noticia_idPersonal_fk FOREIGN KEY(idPersonal) REFERENCES personal(idPersonal)
);
INSERT INTO noticia(titulo, contenido, fechaPublicacion, idPersonal) VALUES("Primer titulo", "Primera Noticia", STR_TO_DATE("19/06/2023", '%d/%m/%Y'), 1);
SELECT * FROM noticia n INNER JOIN personal p ON n.idPersonal=p.idPersonal;
-- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------





CREATE TABLE comentario(
	idComentario		INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    texto				VARCHAR(1000) NOT NULL,
    fechayHora			DATETIME,
    idNoticia			INT NOT NULL,
    idUsuario			INT NOT NULL,
    CONSTRAINT comentario_idNoticia_fk FOREIGN KEY(idNoticia) REFERENCES noticia(idNoticia),
    CONSTRAINT comentario_idUsuario_fk FOREIGN KEY(idUsuario) REFERENCES usuario(idUsuario)
);
INSERT INTO comentario(texto, fechayHora, idNoticia, idUsuario) VALUES("Primer  comentario", STR_TO_DATE("19/06/2023", '%d/%m/%Y'), 1, 1);
SELECT * FROM comentario c INNER JOIN noticia n ON c.idNoticia=n.idNoticia INNER JOIN usuario u ON c.idUsuario=u.idUsuario;

-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------



CREATE TABLE respuesta(
	idRespuesta			INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    texto				VARCHAR(1000) NOT NULL,
    fechayHora			DATETIME,
    idComentario		INT NOT NULL,
    idUsuario			INT NOT NULL,
    CONSTRAINT respuesta_idComentario_fk FOREIGN KEY(idComentario) REFERENCES comentario(idComentario),
    CONSTRAINT respuesta_idUsuario_fk FOREIGN KEY(idUsuario) REFERENCES usuario(idUsuario)
);

INSERT INTO respuesta(texto, fechayHora, idComentario, idUsuario) VALUES("Respuesta uno con el comentario del titulo uno", 
STR_TO_DATE("11/05/2023", '%d/%m/%Y'), 1, 2);
SELECT r.* FROM respuesta r INNER JOIN comentario c ON r.idComentario=c.idComentario INNER JOIN usuario u ON r.idUsuario=u.idUsuario;

-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
